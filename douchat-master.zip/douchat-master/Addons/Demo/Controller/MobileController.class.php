<?php

namespace Addons\Demo\Controller;
use Mp\Controller\MobileBaseController;

/**
 * 示例插件移动端控制器
 * @author 艾逗笔
 */
class MobileController extends MobileBaseController {

}

?>