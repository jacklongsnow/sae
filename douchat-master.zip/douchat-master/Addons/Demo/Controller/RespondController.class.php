<?php

namespace Addons\Demo\Controller;
use Mp\Controller\ApiController;

/**
 * 示例插件响应控制器
 * @author 艾逗笔
 */
class RespondController extends ApiController {

	/**
	 * 微信交互
	 * @param $message array 微信消息数组
	 */
	public function wechat($message = array()) {

	}
}

?>