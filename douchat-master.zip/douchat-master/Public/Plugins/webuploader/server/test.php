<?php 

die;

 ?>