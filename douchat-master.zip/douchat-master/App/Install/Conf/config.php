<?php

/**
 * 安装程序配置文件
 */
define ( 'INSTALL_APP_PATH', realpath ( './' ) . '/' );
return array(
	'DEFAULT_THEME' => 'default',
	'URL_MODEL' => 3,                       // URL模式
    	'URL_ROUTER_ON' => 1
);
