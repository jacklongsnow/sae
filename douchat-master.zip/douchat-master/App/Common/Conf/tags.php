<?php 

return array(
	'view_filter' => array('Behavior\TokenBuildBehavior'),
);


?>